-- MariaDB dump 10.19  Distrib 10.4.31-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.4.31-MariaDB-1:10.4.31+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employers`
--

DROP TABLE IF EXISTS `employers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employers` (
  `employer_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(1024) NOT NULL,
  `company_email` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL,
  `monthly_posts_remaining` int(10) DEFAULT 1,
  PRIMARY KEY (`employer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employers`
--

LOCK TABLES `employers` WRITE;
/*!40000 ALTER TABLE `employers` DISABLE KEYS */;
INSERT INTO `employers` VALUES (10,'HP Web Design','hart@hp.com','$2y$10$pc9NIgwLmDqZqcgRVmZs1.l8lIEaAI/kbrG2McEs0S40NvXjOzsza',1);
/*!40000 ALTER TABLE `employers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `salary` varchar(255) NOT NULL,
  `salary_type` varchar(100) NOT NULL,
  `skillset` varchar(1024) NOT NULL,
  `description` text NOT NULL,
  `benefits` text DEFAULT NULL,
  `application_link` varchar(500) DEFAULT NULL,
  `employer_id` int(11) DEFAULT NULL,
  `date_published` datetime DEFAULT current_timestamp(),
  `date_end` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (96,'PHP Developer','15','hourly','PHP, WordPress, Drupal, Plugin and Module development, SQL','Lorem ipsum dolor sit amet consectetur adipiscing elit libero, ac convallis praesent et sociosqu porta morbi, integer iaculis interdum leo lacinia dui mauris. Mattis purus class pharetra euismod magnis accumsan himenaeos ad egestas, nunc risus et lacinia mi venenatis molestie ac nec, fames pretium quisque dictum scelerisque tortor ligula sem. Mattis quis a feugiat mollis porttitor nisi non sagittis commodo, senectus laoreet dui ridiculus malesuada sociosqu massa dictum maecenas, ornare ad iaculis proin per euismod odio turpis, cum ante cras eleifend netus litora potenti vehicula. Integer ornare vivamus luctus ','- 15 paid leaves\r\n- health insurance on day 1','https://www.w3.org/Provider/Style/dummy.html',7,'2023-10-20 16:01:10','2023-10-27'),(97,'Software Tester','10','hourly','Continuous Integration, SQL, PHP','aptent metus nisl rutrum hac diam vulputate sociosqu, magna mauris montes etiam augue mus natoque. Leo mi gravida cubilia magnis habitasse mattis sollicitudin dignissim, ligula vehicula volutpat conubia quis porta venenatis, libero proin imperdiet auctor sem ultrices feugiat. Aliquam mus posuere id vivamus urna est mauris, maecenas ultricies diam ultrices dignissim dui sollicitudin augue, velit ullamcorper euismod eros massa risus. Dui id penatibus quis urna s','','https://www.w3.org/Provider/Style/dummy.html',7,'2023-10-22 06:12:40','2023-10-23'),(98,'Software Tester','10','hourly','Continuous Integration, SQL, PHP','aptent metus nisl rutrum hac diam vulputate sociosqu, magna mauris montes etiam augue mus natoque. Leo mi gravida cubilia magnis habitasse mattis sollicitudin dignissim, ligula vehicula volutpat conubia quis porta venenatis, libero proin imperdiet auctor sem ultrices feugiat. Aliquam mus posuere id vivamus urna est mauris, maecenas ultricies diam ultrices dignissim dui sollicitudin augue, velit ullamcorper euismod eros massa risus. Dui id penatibus quis urna s','','https://www.w3.org/Provider/Style/dummy.html',7,'2023-10-22 06:12:52','2023-10-23'),(99,'Software Tester','10','hourly','Continuous Integration, SQL, PHP','aptent metus nisl rutrum hac diam vulputate sociosqu, magna mauris montes etiam augue mus natoque. Leo mi gravida cubilia magnis habitasse mattis sollicitudin dignissim, ligula vehicula volutpat conubia quis porta venenatis, libero proin imperdiet auctor sem ultrices feugiat. Aliquam mus posuere id vivamus urna est mauris, maecenas ultricies diam ultrices dignissim dui sollicitudin augue, velit ullamcorper euismod eros massa risus. Dui id penatibus quis urna s','','https://www.w3.org/Provider/Style/dummy.html',7,'2023-10-22 06:13:34','2023-10-23'),(100,'Full-Stack JavaScript Developer','25','hourly','JavaScript, ExpressJS, NodeJS','Lorem ipsum dolor sit amet consectetur adipiscing, elit at dapibus lacinia habitasse diam libero, ullamcorper facilisis ridiculus suscipit nullam. Gravida lobortis consequat potenti phasellus turpis aliquam sodales urna nec sociis orci, morbi lectus habitant natoque vitae fermentum class rutrum eget sapien, ridiculus inceptos pulvinar tempor augue nisl risus quisque ullamcorper ut. Faucibus duis aliquam conubia aenean pharetra primis cum molestie tempus co','','hart@hp.com',7,'2023-10-22 06:28:00','2023-10-28'),(101,'Website Designer','20','hourly','Figma, Adobe Photoshop, Adobe Illustrator','ulum vitae molestie in tincidunt sapien placerat at quis venenatis. Cras arcu varius facilisi mattis mus risus nisi nibh, suscipit nullam metus commodo habitant pretium fames, a malesuada consequat nostra bibendum gravida rutrum. Vehicula consequat cubilia metus','erdiet scelerisque posuere, justo taciti pellentesque euismod vitae ut ','hart@hp.com',7,'2023-10-24 14:08:14','2023-10-26');
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobseekers`
--

DROP TABLE IF EXISTS `jobseekers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobseekers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `email` varchar(1024) NOT NULL,
  `password` varchar(255) NOT NULL,
  `summary` varchar(2025) NOT NULL,
  `position` varchar(1024) NOT NULL,
  `profile_photo` varchar(1024) DEFAULT NULL,
  `skills` varchar(1024) NOT NULL,
  `rate` varchar(1024) NOT NULL,
  `salary_type` varchar(255) NOT NULL,
  `work_background_company_name` varchar(1024) DEFAULT NULL,
  `work_background_position` varchar(255) DEFAULT NULL,
  `work_background_duration` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobseekers`
--

LOCK TABLES `jobseekers` WRITE;
/*!40000 ALTER TABLE `jobseekers` DISABLE KEYS */;
INSERT INTO `jobseekers` VALUES (19,'Hart Pableo','hart@marameodesign.com','$2y$10$Q5Hhpm6CUcLqBf2JWdrSw.Omo5vJ7rUrhBi.uMXg6hi2onH7u3KKS','menaeos porta vel accumsan est posuere. Imperdiet non conubia lacus litora fusce condimentum porttitor eros eu, curabitur commodo placerat netus parturient sollicitudin dignissim curae ultrices sed, vulputate magnis auctor sociosqu laoreet hendrerit ridiculus class. Tempus curabitur mattis platea viverra erat senectus etiam nibh nascetur, sollicitudin fames auctor vel donec ridiculus placerat. Nascetur risus sem nam libero senectus vitae sociis vel ','Full-Stack Developer','1698550018-676logos.svg','PHP','15','hourly','Proweaver','WordPress Developer','sdaadsad');
/*!40000 ALTER TABLE `jobseekers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-29  3:38:46
